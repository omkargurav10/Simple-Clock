# Simple-Clock
![image](https://user-images.githubusercontent.com/89473596/136509531-71512c96-f4ac-4af5-9bee-2c110c8038b0.png)
